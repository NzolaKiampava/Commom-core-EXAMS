# examRank06
42 exam rank 06 based on the given main. This version is very solid because it allocates the memory. And it is not too hard to remember because it takes alot from the `main.c` given during the exam (80 lines / 170).
