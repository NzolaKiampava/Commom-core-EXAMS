gcc ft_printf.c main.c -Werror -Wextra -Wall
./a.out
rm a.out
